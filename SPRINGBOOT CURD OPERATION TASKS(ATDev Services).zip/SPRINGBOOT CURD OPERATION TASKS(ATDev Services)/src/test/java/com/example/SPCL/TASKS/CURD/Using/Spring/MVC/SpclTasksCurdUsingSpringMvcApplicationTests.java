package com.example.SPCL.TASKS.CURD.Using.Spring.MVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpclTasksCurdUsingSpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
