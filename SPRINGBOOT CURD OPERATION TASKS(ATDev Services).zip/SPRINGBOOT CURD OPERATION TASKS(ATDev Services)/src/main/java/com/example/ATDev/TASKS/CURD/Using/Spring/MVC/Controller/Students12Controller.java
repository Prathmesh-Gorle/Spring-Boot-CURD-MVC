package com.example.ATDev.TASKS.CURD.Using.Spring.MVC.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.ATDev.TASKS.CURD.Using.Spring.MVC.Model.Students12;
@Controller
public class Students12Controller {
	@Autowired
	SessionFactory sf;
	@RequestMapping("home")
      public String home() {
		return "home";      //this name must be same to jsp page
	}
	@RequestMapping("createAccount")
    public String SaveCall() {
		return "Insert";          //this name must be same to jsp page
	}
	
	@PostMapping("/Insert")          //this name must be same to return method of above
    public String SaveData(Students12 stud) {
		Session s= sf.openSession();
		Transaction t =s.beginTransaction();
		s.save(stud);
		t.commit();
		return "viewtable";          
	}
	
	@RequestMapping("updatedata")
    public String updateCall() {
		return "update";          //this name must be same to jsp page
	}
	
	@PostMapping("/update")          //this name must be same to return method of above
    public String UpdateData(Students12 stud) {
		Session s= sf.openSession();
		Transaction t =s.beginTransaction();
		s.update(stud);
		t.commit();
		return "viewtable";          
	}
	
	@RequestMapping("deletepage")
	private String deletepage() {
		return "delete";
	}
	
	@RequestMapping("/delete")
	private String deleteDataBase(Students12 student) {
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Students12 ss=s.get(Students12.class, student.getId());
		s.delete(ss);
		t.commit();
		return "viewtable";
	}
	
	@RequestMapping("viewtable")
	private String Showpage() {
		return "viewtable";
	}


}
