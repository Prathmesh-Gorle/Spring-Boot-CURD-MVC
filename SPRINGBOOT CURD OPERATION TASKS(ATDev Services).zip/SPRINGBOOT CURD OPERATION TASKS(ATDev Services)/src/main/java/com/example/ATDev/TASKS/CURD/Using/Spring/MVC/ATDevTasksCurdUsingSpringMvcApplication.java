package com.example.ATDev.TASKS.CURD.Using.Spring.MVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ATDevTasksCurdUsingSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ATDevTasksCurdUsingSpringMvcApplication.class, args);
		System.out.println("Running Project");
	}

}
