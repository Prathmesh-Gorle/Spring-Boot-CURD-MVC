package com.example.ATDev.TASKS.CURD.Using.Spring.MVC.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Students12 {
	@Id
	private String id;
	private String Name;
	private String Lastname;
	private String Age;
	private String Qualification;
	public Students12() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Students12(String id, String name, String lastname, String age, String qualification) {
		super();
		this.id = id;
		Name = name;
		Lastname = lastname;
		Age = age;
		Qualification = qualification;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getQualification() {
		return Qualification;
	}
	public void setQualification(String qualification) {
		Qualification = qualification;
	}
	@Override
	public String toString() {
		return "Students12 [id=" + id + ", Name=" + Name + ", Lastname=" + Lastname + ", Age=" + Age
				+ ", Qualification=" + Qualification + "]";
	}
	
	
}
